hist(result, breaks=50, main="PREVALENCE WITHIN A FLOCK AFTER HORIZ.TRANS.", xlab="Prevalence", col="32")

