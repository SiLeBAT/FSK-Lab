initialize_parents_animals = function(n.iter, Npos, Ntotal){
  
  Prevalence = 100*(rbeta(n.iter, shape1 = Npos + 1, shape2 = Ntotal - Npos + 1 ))
  
  return(Prevalence)
}

result <- initialize_parents_animals(n.iter, Npos, Ntotal)