n.iter <- 200
Npos <- 20
Ntotal <- 100