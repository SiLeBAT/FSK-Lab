hist(result, breaks=50, main="PREVALENCE AMONG FLOCKS AFTER HORIZ.TRANSMI.", xlab="Prevalence", col="32")
