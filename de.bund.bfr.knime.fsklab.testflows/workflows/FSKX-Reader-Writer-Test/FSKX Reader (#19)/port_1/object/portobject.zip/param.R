n.iter <- 200
Npos <- 30
Ntotal <- 100