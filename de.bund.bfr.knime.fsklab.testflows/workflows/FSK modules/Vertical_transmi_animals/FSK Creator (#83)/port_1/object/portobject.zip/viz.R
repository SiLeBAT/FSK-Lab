hist(result, breaks=50, main="PREVALENCE WITHIN A FLOCK AFTER VERTI.TRANSMI.", xlab="Prevalence", col="32")
