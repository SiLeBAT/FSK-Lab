plot(expected_temp)
